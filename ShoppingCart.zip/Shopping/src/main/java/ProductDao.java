import java.util.List;

import product.db.DBconnection;
import product.model.Bill;
import product.model.Product;
public class ProductDao
{
	public DBconnection myConnection()
	{
		//load driver
		//connection
		return null;
	}
	public void saveData(Bill bill)
	{
		//code to save bill data in bill table
		//product data in product table
		
		List<Product> lstProd=bill.getLstProduct();
		for(Product p:lstProd)
		{
			System.out.println(p.getProdId()+"\t"+p.getProdName()+"\t"+p.getProdPrice()+"\t"+p.getProdQty());;
		}
		System.out.println(bill.getBillNo());
		System.out.println(bill.getTotal());
		System.out.println(bill.getCgst());
		System.out.println(bill.getSgst());
		System.out.println(bill.getFinaltotal());
	}
}
